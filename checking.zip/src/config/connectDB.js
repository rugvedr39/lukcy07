const mysql = require('mysql2/promise');

const connection = mysql.createPool({
    host: 'localhost',
    user: 'rohit',
    password: 'rohit',
    database: 'rohit',
});

export default connection;